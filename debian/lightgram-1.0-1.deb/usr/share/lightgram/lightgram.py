import gi
gi.require_version('WebKit2', '4.0')
from gi.repository import WebKit2, Gtk

class WebViewWindow(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="Lightgram")

        self.set_default_size(1001, 740)

        self.set_icon_from_file("/usr/share/lightgram/lightweight.png")

        self.webview = WebKit2.WebView()
        self.webview.load_uri("https://web.telegram.org")

        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.add(self.webview)

        self.add(scrolled_window)

        self.connect("destroy", Gtk.main_quit)

        # Mostrar todo
        self.show_all()

if __name__ == "__main__":
    win = WebViewWindow()
    Gtk.main()
