import gi
import psutil
import subprocess
import platform

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

class SystemInfoApp(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="LSO (Lightweight System Overview)")
        self.set_icon_from_file("ohjhas.png")
        self.set_default_size(400, 300)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.add(vbox)

        processor_info = f"Procesador: {self.get_cpu_info()}"
        gpu_info = f"Grafica: {self.get_gpu_info()}"
        ram_info = f"Memoria RAM: {self.get_ram_info()}"
        kernel_info = f"Version del Kernel linux: {platform.uname().release}"
        system_name_info = f"Nombre del Sistema: {self.get_system_name()}"

        processor_label = Gtk.Label(label=processor_info)
        gpu_label = Gtk.Label(label=gpu_info)
        ram_label = Gtk.Label(label=ram_info)
        kernel_label = Gtk.Label(label=kernel_info)
        system_name_label = Gtk.Label(label=system_name_info)

        vbox.pack_start(processor_label, True, True, 0)
        vbox.pack_start(gpu_label, True, True, 0)
        vbox.pack_start(ram_label, True, True, 0)
        vbox.pack_start(kernel_label, True, True, 0)
        vbox.pack_start(system_name_label, True, True, 0)

    def get_cpu_info(self):
        try:
            result = subprocess.check_output(["lscpu"]).decode("utf-8")
            model_line = [line for line in result.splitlines() if "Model name:" in line][0]
            model_name = model_line.split(":")[1].strip()
            return model_name
        except (subprocess.CalledProcessError, IndexError):
            return "No hay"

    def get_gpu_info(self):
        try:
            result = subprocess.check_output(["lspci", "-vnn"]).decode("utf-8")
            gpu_line = [line for line in result.splitlines() if "VGA" in line][0]
            gpu_name = gpu_line.split(":")[2].strip()
            return gpu_name
        except (subprocess.CalledProcessError, IndexError):
            return "No hay"

    def get_ram_info(self):
        ram_info = psutil.virtual_memory()
        return f"{ram_info.total / (1024 ** 3):.2f} GB"

    def get_system_name(self):
        try:
            with open("/etc/lsb-release", "r") as file:
                for line in file:
                    if line.startswith("PRETTY_NAME="):
                        return line.split("=")[1].strip().strip('"')
        except FileNotFoundError:
        #decir que el sistema no tiene nombre
            return "El sistema no tiene nombre"

if __name__ == "__main__":
    win = SystemInfoApp()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
